/*
 * Copyright (c) 2017 Brian Barto
 * 
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GPL License. See LICENSE for more details.
 */

#ifndef NMSCHARSET_H
#define NMSCHARSET_H 1

// Function prototypes
char *nmscharset_get_random(void);

#endif
